﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int _score = 0; //Početno stanje bodova
    [SerializeField]
    private int _initialTimeScoreBonus = 10000; //Max bonus bodova
    [SerializeField]
    private int _bonusScorePerSecondLost = 40; //Po sekundi kolko se bodova gubi
    [SerializeField]
    private int _scorePerCard = 20; //Po karti kolko bodova (po paru 40)
    private TimeCounter _timeCounter;
    public int score
    {
        get
        {
            return _score;
        }
        set
        {
            _score = value;
        }
    }
    void Start()
    {
        _timeCounter = FindObjectOfType<TimeCounter>(); //Nađe timecounter skriptu
    }
    public void AddScore() //Skor tokom igre
    {
        _score += 20;
    }
    public void CalculateEndScore() //Konačni skor
    {
        _score += Mathf.Clamp(_initialTimeScoreBonus - _bonusScorePerSecondLost * _timeCounter.timeCounted, 0, _initialTimeScoreBonus);
    }
}