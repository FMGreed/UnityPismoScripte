﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Koristi se UI

public class SetScoreText : MonoBehaviour
{
    public Text _scoreText; //Text "UI" za prikaz bodova na sceni
    ScoreManager _scoreManager; //ScoreManager skripta ili drugačijeg naziva kako ste nazvali svoju skriptu

    void Start() //Učitaj odmah gdje je ScoreManager skripta
    {
        _scoreManager = FindObjectOfType<ScoreManager>(); //Traženje GameObjecta sa skriptom "ScoreManager" na sceni
    }
    void Update() //Svaki frame provjeri jel se score promjenio i ako je promjeni ga
    {
        _scoreText.text = "Score: " + _scoreManager.score; //Mjenja Text na UI-u u "Score: " i score bodovi
    }
}