﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField]
    GameObject _firstCard = null; //prva odabrana karta
    [SerializeField]
    GameObject _secondCard = null; // druga odabrana karta
    [SerializeField]
    int _cardsLeft; //Broj preostalih karata
    bool _canFlip = true; //Može li se okrenuti karta
    [Header("Brzina mjenjanja slike: ")]
    public float _timeBetweenFlips = 0.65f; //Mislim da je najbolje, ali vi si možete promjeniti
    ScoreManager _scoreManager;
    [Header("Objekt koji se prikazuje za win: ")]
    public GameObject _win; //Slika ili text sa UI-a koji će se prikazati kada pobjedimo
    TimeCounter _timeCounter;
    public bool canFlip
    {
        get
        {
            return _canFlip;
        }
        set
        {
            _canFlip = value;
        }
    }
    public int cardsLeft
    {
        get
        {
            return _cardsLeft;
        }
        set
        {
            _cardsLeft = value;
        }
    }
    void Start()
    {
        _win.SetActive(false); //postavi win objekt da je neaktivan
        _scoreManager = FindObjectOfType<ScoreManager>(); //Traži gameobjekt na sceni koji ima na sebi skriptu "ScoreManager"
        _timeCounter = FindObjectOfType<TimeCounter>(); // Traži gameobjekt na sceni koji ima na sebi skriptu "TimeCounter"
    }
    public void AddCard(GameObject card) //This function will be called from CardController class
    {
        if (_firstCard == null) //Dodajte prvu kartu
        {
            _firstCard = card;
        }
        else //Dodaje drugu kartu i provjerava jesu li iste
        {
            _secondCard = card;
            _canFlip = false;
            if (CheckIfMatch())
            {
                DecreaseCardCount();
                _scoreManager.AddScore(); //Dva puta jer imamo dvije karte
                _scoreManager.AddScore(); 
                StartCoroutine(DeactivateCards());
            }
            else
            {
                StartCoroutine(FlipCards());
            }
        }
    }
    IEnumerator DeactivateCards()
    {
        yield return new WaitForSeconds(_timeBetweenFlips); //Traje da igrač može vidjet odabrane karte da ih ne vrati u poletno stanje prebrzo
        _firstCard.SetActive(false);
        _secondCard.SetActive(false);
        Reset();
    }
    IEnumerator FlipCards() //Vraća slike na početnu
    {
        yield return new WaitForSeconds(_timeBetweenFlips); 
        _firstCard.GetComponent<CardController>().ChangeSide();
        _secondCard.GetComponent<CardController>().ChangeSide();
        Reset();
    }
    public void Reset() //Reset metoda koja vraća na početne vrijednosti
    {
        _firstCard = null;
        _secondCard = null;
        _canFlip = true;
    }
    public void DecreaseCardCount() //Oduzima broj karata
    {
        _cardsLeft -= 2;
        if (_cardsLeft <= 0) // Ako je ostalo 0 karata onda pobjeda
        {
            _win.SetActive(true); 
            _timeCounter.countTime = false; 
            _scoreManager.CalculateEndScore(); 
        }
    }
    bool CheckIfMatch() // Bool metoda koja provjerava jesu li karte iste po imenu
    {
        if (_firstCard.GetComponent<CardController>().cardName == _secondCard.GetComponent<CardController>().cardName)
        {
            return true;
        }
        return false;
    }
}