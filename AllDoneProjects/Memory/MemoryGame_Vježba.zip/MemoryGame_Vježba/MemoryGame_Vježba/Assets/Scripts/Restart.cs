﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //Obavezno dodati SceneManagment

public class Restart : MonoBehaviour
{
    //metoda za resetovanje scene
    public void RestartGame()
    {
        //Kada koristimo GetActiveScene().name učitavamo naziv trenutne scene
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}