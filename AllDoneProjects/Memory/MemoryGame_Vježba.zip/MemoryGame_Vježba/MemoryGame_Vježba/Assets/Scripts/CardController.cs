﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardController : MonoBehaviour
{
    [SerializeField]
    private string _cardName; //Koristi se za usporedbu jesu li dvije karte iste
    private bool _isFliped = false; //Bool jeli karta preokrenuta
    Sprite _backSideCardSprite; //Zadnje lice karte (prvo aktivno), uvijek isto
    public Sprite _frontSideCardSprite; //Prednje lice karte, uvijek različito, osim za par
    SpriteRenderer _spriteRenderer;
    GameManager _gameManager;
    private void Start()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _gameManager = FindObjectOfType<GameManager>(); //Traži GameManagera na sceni
        _backSideCardSprite = _spriteRenderer.sprite;
    }
    public string cardName //Stvaramo public od _cardNamea za bazu kako bih gamemanager i score imali pristup tome bez mjenjana
    {
        get
        {
            return _cardName;
        }
        set
        {
            _cardName = value;
        }
    }
    private void OnMouseDown() //Metodata kada god igrač klikne na kartu
    {
        if (!_isFliped)
        {
            _gameManager.AddCard(gameObject); //Dodaje kartu u AddCard kao gameObject
            ChangeSide(); //Flipa se
        }
    }
    public void ChangeSide() // aktivira Prednje lice karte kao aktivno
    {
        if (!_isFliped)
        {
            _spriteRenderer.sprite = _frontSideCardSprite;
            _isFliped = true;
        }
        else
        {
            _spriteRenderer.sprite = _backSideCardSprite;
            _isFliped = false;
        }
    }
}