﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Koristimo UI

public class TimeCounter : MonoBehaviour
{
    float _timeCounter = 0.0f; //Početni broj countera
    public Text _timeText; // Text na UI-u gdje se prikazuje vrijeme
    int _counter = 1; //Counter za cijele brojeve
    bool _countTime = true; //bool dali brojimo vrijeme
    public bool countTime //učitava bool _countTime za public
    {
        get
        {
            return _countTime;
        }
        set
        {
            _countTime = value;
        }
    }
    public int timeCounted
    {
        get
        {
            return _counter;
        }
    }
    void Update()
    {
        if (_countTime) //Ako je bool točan prvo kreće "_timeCounter += Time.deltaTime;", a zatim if
        {
            _timeCounter += Time.deltaTime;

            if (_timeCounter >= _counter) 
            {
                _timeText.text = "Time: " + _counter; //Promjeni text na UI-u
                _counter++; // Dodaj 1 cijeli broj na counter
            }
        }
    }
}