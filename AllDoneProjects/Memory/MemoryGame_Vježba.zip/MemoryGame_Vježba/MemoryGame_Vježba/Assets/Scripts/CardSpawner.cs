﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardSpawner : MonoBehaviour
{
    [Header("Cards prefabs:")]
    public List<GameObject> _cardsToSpawn;
    [SerializeField]
    private List<int> _cardsToSpawnNumber; //Broj karata za stvoriti
    
    public Transform _startPoint; //Početna točka stvaranja (Preporučeno -7, 3.5, 0)
    [Header("Broj redaka:")]
    public int _rows = 5; //Broj redaka
    [Header("Broj stupaca:")]
    public int _columns = 12;
    [Header("Udaljenos po X rubovima:")]
    public float x_Distance = 1.25f;
    [Header("Udaljenos po Y rubovima:")]
    public float y_Distance = 1.75f;
    GameManager _gameManager;

    void Start()
    {
        _gameManager = FindObjectOfType<GameManager>();
    }
    private void Update() //Objekti se stvaraju u Updateu
    {
        Spawn();
        gameObject.SetActive(false); //Nakon stvaranja karata deaktivira se gameobject da ne radi nepotrebno u pozadini i ne učita ponovo update
    }

    void Spawn() //Metoda stvaranja
    {
        int cardNumber;
        int maxCards = _rows * _columns; //Max broj karata stupci * redci
        if (maxCards % 2 == 0) //Cijelobrojno djeljenje, dakle 5 * 5 = 25 neće se moći stvoriti jer je neparan broj karata
        {
            _cardsToSpawnNumber = new List<int>(); //Lista stvaranja
            _gameManager.cardsLeft = maxCards; //Dodjeljuje da su preostale karte jednake maksimalnom broju karata
            for (int i = 0; i < _cardsToSpawn.Count; i++) 
            {
                _cardsToSpawnNumber.Add(0);
            }
            for (int i = 0; i < _cardsToSpawnNumber.Count; i++)
            {
                _cardsToSpawnNumber[i] = Random.Range(0, (int)(maxCards / (_cardsToSpawn.Count - 1)) + 1);
                if (_cardsToSpawnNumber[i] % 2 != 0)
                {
                    if (Random.Range(0, 100) < 50)
                    {
                        _cardsToSpawnNumber[i]--;
                    }
                    else
                    {
                        _cardsToSpawnNumber[i]++;
                    }
                }
            }
            int sum = 0;
            for (int i = 0; i < _cardsToSpawnNumber.Count; i++)
            {
                sum += _cardsToSpawnNumber[i];
            }
            if (sum < maxCards)
            {
                for (int i = 0; i < (int)((maxCards - sum) / 2); i++)
                {
                    _cardsToSpawnNumber[Random.Range(0, _cardsToSpawn.Count - 1)] += 2; //Because it must be even
                }
            }
            bool forward = true;
            for (int i = 0; i < _rows; i++)
            {
                for (int j = 0; j < _columns; j++)
                {
                    cardNumber = Random.Range(0, _cardsToSpawnNumber.Count - 1);
                    if (_cardsToSpawnNumber[cardNumber] > 0)
                    {
                        Instantiate(_cardsToSpawn[cardNumber], new Vector3(_startPoint.position.x + x_Distance * j, _startPoint.position.y - y_Distance * i, _startPoint.position.z), Quaternion.Euler(0.0f, 0.0f, 0.0f));
                        _cardsToSpawnNumber[cardNumber]--;
                    }
                    else
                    {
                        if (forward)
                        {
                            for (int k = 0; k < _cardsToSpawnNumber.Count; k++)
                            {
                                if (_cardsToSpawnNumber[k] > 0)
                                {
                                    Instantiate(_cardsToSpawn[k], new Vector3(_startPoint.position.x + x_Distance * j, _startPoint.position.y - y_Distance * i, _startPoint.position.z), Quaternion.Euler(0.0f, 0.0f, 0.0f));
                                    _cardsToSpawnNumber[k]--;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            for (int k = _cardsToSpawnNumber.Count - 1; k >= 0; k--)
                            {
                                if (_cardsToSpawnNumber[k] > 0)
                                {
                                    Instantiate(_cardsToSpawn[k], new Vector3(_startPoint.position.x + x_Distance * j, _startPoint.position.y - y_Distance * i, _startPoint.position.z), Quaternion.Euler(0.0f, 0.0f, 0.0f));
                                    _cardsToSpawnNumber[k]--;
                                    break;
                                }
                            }
                        }
                        forward = !forward;
                    }
                }
            }
        }
        else
        {
            Debug.Log("Broj karata nije jednak!");
        }
    }
}